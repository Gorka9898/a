<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function sinValores()
    {

        return view("");
        
    }

    public function conValores(Request $request)
    {
        
    }
    public function todo(Request $request)
    {
        
    }
}
