<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormController;
use App\Http\Controllers\FormController2;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    //return view('welcome');
    return "Home";
})->name('home.index');

Route::get('/contacto', function () {
    return "Contacto";
})->name('home.contacto');

Route::group([], function () {
    Route::get('/post-recientes/{hace_dias?}', function ($hace_dias = 0) {
        return "Este post es de hace " . $hace_dias . " dias";
    })->name('posts.recientes.index')
    ->where(["hace_dias" => '[0-9]']);
    
    Route::get('/posts/{id}', function ($id) {
        return "" . $id;
    })->name('posts.ensenar')
    ->where(["id" => '[a-zA-z]']);
});

*/





/*

Route::get('/', function () {

    $name="Gorka";
    return $name;
    
});


Route::get('/ConArray', function () {

    $name=["Platanao", "Microondas", "Labie"];

    for ($i=0; $i <count($name) ; $i++) { 
        echo $name[$i]." ";
    };
    
    
});

Route::get('/array/{id}', function ($id) {

    $arr=["Gorka", "Erikc"];
    
    return "El nombre es ".$arr[$id];


   });




   Route::get('/pintar', function () {

    $cont=1;
        $arr=["AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaaaa, me mordieron los huevos ", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaaaa, el pene tambien"];

    for ($i=0; $i < 20; $i++) { 

        
        if ($cont%2==0) {

            echo "<p style='background:lightgreen'>".$arr[1]. "</p>";

            
           
        }else{

            echo $arr[0];

        }

        $cont++;
    }


   });


   */

  Route::get('/', function () {

    return view("FormController");
    
});


Route::get('/transmitir', [FormController::class, 'index']);

Route::controller(FormController2::class)

    ->group(function () {
Route::get('/transmitir2', 'index2');
Route::get('/transmitir3/{id}', 'index3');
Route::post('/transmitir4', 'index4');

    });
