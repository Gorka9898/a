<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController2 extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index2()
    {
        $aaa=["AAAAA", "BBBBBB", "CCCCCC"];
        for ($i=0; $i < count($aaa); $i++) { 
            echo "<br><br>";
            echo $aaa[$i];
        }
    }

    public function index3($id)
    {
        $aaa=["AAAAA", "BBBBBB", "CCCCCC"];
        return $aaa[$id];
    }

    public function index4(Request $request)
    {
        $nombre= $request->nombree;
        $apellido=$request->apelllido;
        return "Nombre: ".$nombre."<br> Apellido:".$apellido;
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
