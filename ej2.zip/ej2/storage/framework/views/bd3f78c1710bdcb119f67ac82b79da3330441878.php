<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<form action="/transmitir">
<?php echo csrf_field(); ?>

    Nombre: <input type="text">

    <input type="submit">



</form>


<br>

<br>

<form action="/transmitir2">
<?php echo csrf_field(); ?>

    Nombre: <input type="text">

    <input type="submit">



</form>



<br>

<br>

<form action="/transmitir3/{id}">
<?php echo csrf_field(); ?>

    Nombre: <input type="text">

    <input type="submit">



</form>



<br>

<br>

<form action="/transmitir4" method="POST">
<?php echo csrf_field(); ?>

    Nombre: <input type="text" name="nombree"><br>
    Apellido: <input type="text" name="apelllido">

    <input type="submit">



</form>
    
</body>
</html><?php /**PATH /home/zubiri/Escritorio/Servidor/ej2/resources/views/FormController.blade.php ENDPATH**/ ?>